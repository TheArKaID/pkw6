

<?php $__env->startSection('title', 'Index'); ?>

<?php $__env->startSection('container'); ?>
    <div class="container">
        <div class="row">
            <div class="col-10">
                <h1>
                    Laravel Index Page
                </h1>
            </div>
        </div>
        <a href="/jadwal/tambah">Tambah Jadwal</a>
        <div class="row">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nama Mata Kuliah</th>
                    <th scope="col">Waktu</th>
                    <th scope="col">Lab</th>
                    <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $row = 1    
                    ?>
                    <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($row); ?></td>
                            <td><?php echo e($j->namamatkul); ?></td>
                            <td><?php echo e($j->waktu); ?></td>
                            <td><?php echo e($j->lab); ?></td>
                            <th>
                                <a href="/jadwal/edit/<?php echo e($j->id); ?>">Edit</a>
                                <a href="/jadwal/hapus/<?php echo e($j->id); ?>">Hapus</a>
                            </th>
                        </tr>
                        <?php
                        $row +=1   
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pkw6/resources/views/jadwal/index.blade.php ENDPATH**/ ?>