

<?php $__env->startSection('title', 'Index'); ?>

<?php $__env->startSection('container'); ?>
    <div class="container">
        <div class="row">
            <div class="col-10">
                <h1>
                    Laravel Index Page
                </h1>
            </div>
        </div>
        <a href="/jadwal/tambah">Tambah Jadwal</a>
        <div class="row">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nama Mata Kuliah</th>
                    <th scope="col">Waktu</th>
                    <th scope="col">Lab</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <form action="/jadwal/edit" method="post">
                        <?php echo e(csrf_field()); ?>

                    <tr>
                        <td scope="row">1</td>
                        <td><input type="text" name="namamatkul" id="namamatkul" value="<?php echo e($jadwal->namamatkul); ?>"></td>
                        <td><input type="text" name="waktu" id="waktu" value="<?php echo e($jadwal->waktu); ?>"></td>
                        <td><input type="text" name="lab" id="lab" value="<?php echo e($jadwal->lab); ?>"></td>
                        <th>
                            <input type="text" name="id" id="id" value="<?php echo e($jadwal->id); ?>" hidden>
                           <button type="submit">Simpan</button>
                        </th>
                    </tr>
                </form>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/pkw6/resources/views/jadwal/edit.blade.php ENDPATH**/ ?>