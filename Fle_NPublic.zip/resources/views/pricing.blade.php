@extends('layout.main')

@section('title', 'Pricing')

@section('container')
    <div class="container">
        <div class="row">
            <div class="col-10">
                <h1>
                    {{-- Laravel Pricing Page --}}
                    {{$nama_halaman}}
                </h1>
            </div>
        </div>
    </div>
@endsection
