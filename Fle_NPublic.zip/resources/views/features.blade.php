@extends('layout.main')

@section('title', 'Features')

@section('container')
    <div class="container">
        <div class="row">
            <div class="col-10">
                <h1>
                    Laravel Features Page
                </h1>
            </div>
        </div>
    </div>
@endsection
