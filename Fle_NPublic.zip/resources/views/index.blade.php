@extends('layout.main')

@section('title', 'Index')

@section('container')
    <div class="container">
        <div class="row">
            <div class="col-10">
                <h1>
                    Laravel Index Page
                </h1>
            </div>
        </div>
    </div>
@endsection
